package projetoLoja;

public class Funcionario {
	private String Nome, RG;//apagar e deixar no banco
	private double salario = 880;//criar mais uma coluna pro salario total tendo como base o salario minimo

	Funcionario(String nome, String RG, String tipo){
		this.Nome = nome;
		this.RG = RG;
		//insere no banco
		BD bd = new BD();
		bd.insert(nome, RG, tipo);
	}
	public String getNome() {
		return Nome;//resultset select nome from funcionarios
	}
	public String getRG() {
		return RG;
	}
	public double getSalario() {
		return salario;
	}
}
